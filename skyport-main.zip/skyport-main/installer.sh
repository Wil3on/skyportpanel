#!/bin/bash
cd /tmp && git clone https://github.com/G-flame/skyport.git && sudo bash /tmp/skyport/script.sh
