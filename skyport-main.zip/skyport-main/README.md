SKYPORT INSTALLER
---
## ABOUT 
  A skyport panel and daemon installer and Uninstaller that makes it easy to setup the depreciate skyport project in an working condition !!
this project was made for debian based OSes and is still receiving constant bug fixes !!
---
## INSTALLATIONS

```bash
cd /tmp && git clone https://github.com/G-flame/skyport.git && sudo bash /tmp/skyport/script.sh
```
---
## CREDITS
skyport project by skyportlabs 
and installer by (G-flame)[] 
(achul)[] (privt)[] and (matt)[]
- thank-you! for using my project 
